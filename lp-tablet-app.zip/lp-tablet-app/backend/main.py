import asyncio
import os
from datetime import datetime, timezone

from dotenv import load_dotenv
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, Header
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

import arca_repository
from database import app_connection, init_app_db
from models import (
    AssegnaTabletRequest,
    ConfermaLPResponse,
    LPHeaderOut,
    LPRigaOut,
    ModificaRigaRequest,
    RegistraTabletRequest,
    TabletInfo,
)
from ws_manager import manager

load_dotenv()

APP_SHARED_TOKEN = os.getenv("APP_SHARED_TOKEN", "cambia_questo_token")
POLL_INTERVAL_SECONDS = int(os.getenv("POLL_INTERVAL_SECONDS", "10"))

app = FastAPI(title="LP Tablet App")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # TODO: restringere ai domini/IP Tailscale reali in produzione
    allow_methods=["*"],
    allow_headers=["*"],
)


def check_token(x_app_token: str | None = Header(default=None)):
    if x_app_token != APP_SHARED_TOKEN:
        raise HTTPException(status_code=401, detail="Token non valido")


# ---------------------------------------------------------------------
# Avvio: inizializza DB locale e lancia il polling in background
# ---------------------------------------------------------------------

@app.on_event("startup")
async def startup():
    init_app_db()
    asyncio.create_task(_poll_nuovi_lp_loop())


async def _poll_nuovi_lp_loop():
    """Ogni N secondi controlla se ci sono nuovi LP su ARCA non ancora
    conosciuti dall'app e, se si', li registra localmente e avvisa
    l'ufficio via WebSocket."""
    while True:
        try:
            _controlla_nuovi_lp()
        except Exception as e:
            # Non blocca il loop: logga e riprova al giro successivo
            print(f"[poll] errore lettura ARCA: {e}")
        await asyncio.sleep(POLL_INTERVAL_SECONDS)


def _controlla_nuovi_lp():
    lp_arca = arca_repository.get_nuovi_lp()
    with app_connection() as conn:
        esistenti = {
            row["lp_id"] for row in conn.execute("SELECT lp_id FROM lp_assegnazioni")
        }
        nuovi = [lp for lp in lp_arca if str(lp["lp_id"]) not in esistenti]
        for lp in nuovi:
            conn.execute(
                "INSERT INTO lp_assegnazioni (lp_id, stato) VALUES (?, 'nuovo')",
                (str(lp["lp_id"]),),
            )

    if nuovi:
        asyncio.create_task(
            manager.send_to_channel("office", {"tipo": "nuovi_lp", "lp": nuovi})
        )


# ---------------------------------------------------------------------
# Rotte: Tablet (registrazione / elenco per l'ufficio)
# ---------------------------------------------------------------------

@app.post("/api/tablets", dependencies=[])
def registra_tablet(req: RegistraTabletRequest):
    with app_connection() as conn:
        conn.execute(
            """
            INSERT INTO tablets (id, nome, ultimo_visto) VALUES (?, ?, ?)
            ON CONFLICT(id) DO UPDATE SET nome=excluded.nome, ultimo_visto=excluded.ultimo_visto
            """,
            (req.id, req.nome, datetime.now(timezone.utc).isoformat()),
        )
    return {"ok": True}


@app.get("/api/tablets", response_model=list[TabletInfo])
def elenco_tablet():
    with app_connection() as conn:
        righe = conn.execute("SELECT id, nome FROM tablets").fetchall()
    return [
        TabletInfo(id=r["id"], nome=r["nome"], online=manager.is_online(f"tablet:{r['id']}"))
        for r in righe
    ]


# ---------------------------------------------------------------------
# Rotte: LP lato ufficio
# ---------------------------------------------------------------------

@app.get("/api/lp/nuovi", response_model=list[LPHeaderOut])
def lp_nuovi():
    with app_connection() as conn:
        righe = conn.execute(
            "SELECT lp_id, stato, tablet_id FROM lp_assegnazioni WHERE stato = 'nuovo'"
        ).fetchall()
    return [LPHeaderOut(lp_id=r["lp_id"], stato=r["stato"], tablet_id=r["tablet_id"]) for r in righe]


@app.post("/api/lp/{lp_id}/assegna")
async def assegna_lp(lp_id: str, req: AssegnaTabletRequest):
    righe_arca = arca_repository.get_righe_lp(lp_id)

    with app_connection() as conn:
        conn.execute(
            "UPDATE lp_assegnazioni SET tablet_id = ?, stato = 'inviato_tablet', aggiornato_il = CURRENT_TIMESTAMP WHERE lp_id = ?",
            (req.tablet_id, lp_id),
        )
        conn.execute("DELETE FROM lp_righe_stato WHERE lp_id = ?", (lp_id,))
        for r in righe_arca:
            conn.execute(
                """
                INSERT INTO lp_righe_stato
                    (lp_id, riga_id_arca, articolo_codice, articolo_descrizione,
                     quantita_originale, quantita_corrente, eliminata)
                VALUES (?, ?, ?, ?, ?, ?, 0)
                """,
                (
                    lp_id,
                    str(r["riga_id_arca"]),
                    r["articolo_codice"],
                    r["articolo_descrizione"],
                    r["quantita"],
                    r["quantita"],
                ),
            )

    lp_out = _leggi_lp_completo(lp_id)
    await manager.send_to_channel(f"tablet:{req.tablet_id}", {"tipo": "lp_assegnato", "lp": lp_out.model_dump()})
    return {"ok": True}


def _leggi_lp_completo(lp_id: str) -> LPHeaderOut:
    with app_connection() as conn:
        testata = conn.execute(
            "SELECT lp_id, stato, tablet_id FROM lp_assegnazioni WHERE lp_id = ?", (lp_id,)
        ).fetchone()
        if not testata:
            raise HTTPException(status_code=404, detail="LP non trovato")
        righe = conn.execute(
            "SELECT * FROM lp_righe_stato WHERE lp_id = ?", (lp_id,)
        ).fetchall()

    return LPHeaderOut(
        lp_id=testata["lp_id"],
        stato=testata["stato"],
        tablet_id=testata["tablet_id"],
        righe=[
            LPRigaOut(
                riga_id_arca=r["riga_id_arca"],
                articolo_codice=r["articolo_codice"],
                articolo_descrizione=r["articolo_descrizione"],
                quantita_originale=r["quantita_originale"],
                quantita_corrente=r["quantita_corrente"],
                eliminata=bool(r["eliminata"]),
            )
            for r in righe
        ],
    )


# ---------------------------------------------------------------------
# Rotte: LP lato tablet (magazziniere)
# ---------------------------------------------------------------------

@app.get("/api/lp/{lp_id}", response_model=LPHeaderOut)
def dettaglio_lp(lp_id: str):
    return _leggi_lp_completo(lp_id)


@app.patch("/api/lp/{lp_id}/riga/{riga_id_arca}")
async def modifica_riga(lp_id: str, riga_id_arca: str, req: ModificaRigaRequest):
    with app_connection() as conn:
        conn.execute(
            "UPDATE lp_righe_stato SET quantita_corrente = ? WHERE lp_id = ? AND riga_id_arca = ?",
            (req.quantita, lp_id, riga_id_arca),
        )
    await _notifica_office_stato(lp_id)
    return {"ok": True}


@app.delete("/api/lp/{lp_id}/riga/{riga_id_arca}")
async def elimina_riga(lp_id: str, riga_id_arca: str):
    with app_connection() as conn:
        conn.execute(
            "UPDATE lp_righe_stato SET eliminata = 1 WHERE lp_id = ? AND riga_id_arca = ?",
            (lp_id, riga_id_arca),
        )
    await _notifica_office_stato(lp_id)
    return {"ok": True}


async def _notifica_office_stato(lp_id: str):
    lp = _leggi_lp_completo(lp_id)
    await manager.send_to_channel("office", {"tipo": "lp_aggiornato", "lp": lp.model_dump()})


@app.post("/api/lp/{lp_id}/conferma", response_model=ConfermaLPResponse)
async def conferma_lp(lp_id: str):
    lp = _leggi_lp_completo(lp_id)

    righe_confermate = [
        {
            "riga_id_arca": r.riga_id_arca,
            "quantita_corrente": r.quantita_corrente,
            "eliminata": r.eliminata,
        }
        for r in lp.righe
    ]

    try:
        arca_repository.scrivi_esito_finale_lp(lp_id, righe_confermate)
    except Exception as e:
        return ConfermaLPResponse(lp_id=lp_id, esito="errore", dettaglio=str(e))

    with app_connection() as conn:
        conn.execute(
            "UPDATE lp_assegnazioni SET stato = 'confermato', aggiornato_il = CURRENT_TIMESTAMP WHERE lp_id = ?",
            (lp_id,),
        )

    await manager.send_to_channel(
        "office", {"tipo": "lp_confermato", "lp_id": lp_id}
    )
    return ConfermaLPResponse(lp_id=lp_id, esito="ok")


# ---------------------------------------------------------------------
# WebSocket
# ---------------------------------------------------------------------

@app.websocket("/ws/office")
async def ws_office(websocket: WebSocket):
    await manager.connect("office", websocket)
    try:
        while True:
            await websocket.receive_text()  # non usiamo messaggi in arrivo, solo keepalive
    except WebSocketDisconnect:
        manager.disconnect("office", websocket)


@app.websocket("/ws/tablet/{tablet_id}")
async def ws_tablet(websocket: WebSocket, tablet_id: str):
    channel = f"tablet:{tablet_id}"
    await manager.connect(channel, websocket)
    try:
        while True:
            await websocket.receive_text()
    except WebSocketDisconnect:
        manager.disconnect(channel, websocket)


# Serve le pagine frontend statiche (office.html, tablet.html)
app.mount("/", StaticFiles(directory="../frontend", html=True), name="frontend")
