"""
Questo file e' l'UNICO punto in cui il codice parla con le tabelle di ARCA.

########################################################################
# IMPORTANTE - DA FARE PRIMA DI TUTTO
#
# Non conosco lo schema reale del tuo database ARCA Evolution (nomi
# tabelle/colonne per Liste di Prelievo). I nomi qui sotto (LP_TESTATA,
# LP_RIGHE, ecc.) sono PLACEHOLDER plausibili ma quasi certamente sbagliati.
#
# Usa discover_schema.py per trovare i nomi reali, poi sostituisci le
# query in questo file. Cerca ogni "# TODO ARCA:" qui sotto.
########################################################################
"""

from database import arca_connection


def get_nuovi_lp() -> list[dict]:
    """Restituisce gli LP creati su ARCA non ancora presi in carico
    dall'app (cioe' non presenti nella tabella locale lp_assegnazioni,
    filtro fatto a livello applicativo in main.py).

    # TODO ARCA: sostituire con i nomi reali di tabella/colonne.
    Ipotesi di struttura:
      LP_TESTATA(ID_LP, NUMERO, DATA_CREAZIONE, DESTINAZIONE, STATO)
    """
    query = """
        SELECT
            ID_LP        AS lp_id,
            NUMERO       AS numero,
            DATA_CREAZIONE AS data_creazione,
            DESTINAZIONE AS cliente_destinazione
        FROM LP_TESTATA
        WHERE STATO = 'APERTO'
        ORDER BY DATA_CREAZIONE DESC
    """
    with arca_connection() as conn:
        cur = conn.cursor()
        cur.execute(query)
        cols = [c[0] for c in cur.description]
        return [dict(zip(cols, row)) for row in cur.fetchall()]


def get_righe_lp(lp_id: str) -> list[dict]:
    """Righe (articoli/quantita') di un LP.

    # TODO ARCA: sostituire con i nomi reali.
    Ipotesi di struttura:
      LP_RIGHE(ID_RIGA, ID_LP, COD_ARTICOLO, DESCRIZIONE, QUANTITA)
    """
    query = """
        SELECT
            ID_RIGA       AS riga_id_arca,
            COD_ARTICOLO  AS articolo_codice,
            DESCRIZIONE   AS articolo_descrizione,
            QUANTITA      AS quantita
        FROM LP_RIGHE
        WHERE ID_LP = ?
        ORDER BY ID_RIGA
    """
    with arca_connection() as conn:
        cur = conn.cursor()
        cur.execute(query, lp_id)
        cols = [c[0] for c in cur.description]
        return [dict(zip(cols, row)) for row in cur.fetchall()]


def scrivi_esito_finale_lp(lp_id: str, righe_confermate: list[dict]) -> None:
    """Scrittura FINALE su ARCA quando il magazziniere preme 'Invia'.

    righe_confermate: lista di dict con riga_id_arca, quantita_corrente, eliminata

    # TODO ARCA: questa e' la parte piu' delicata. Prima di implementarla
    # per davvero, verifica con la documentazione/assistenza ARCA (o con
    # un test su un DB di prova) come l'applicativo si aspetta che vengano
    # modificate le righe di un LP, perche' potrebbero esserci trigger,
    # numerazioni o vincoli che una UPDATE/DELETE diretta rompe.
    #
    # Sotto un'implementazione di esempio (UPDATE quantita' + DELETE
    # righe rimosse + cambio stato testata), da validare riga per riga.
    """
    with arca_connection() as conn:
        cur = conn.cursor()
        try:
            for riga in righe_confermate:
                if riga["eliminata"]:
                    cur.execute(
                        "DELETE FROM LP_RIGHE WHERE ID_RIGA = ?",
                        riga["riga_id_arca"],
                    )
                else:
                    cur.execute(
                        "UPDATE LP_RIGHE SET QUANTITA = ? WHERE ID_RIGA = ?",
                        riga["quantita_corrente"],
                        riga["riga_id_arca"],
                    )

            # TODO ARCA: verificare il nome/valore corretto dello stato
            # che permette all'ufficio di generare la bolla da questo LP.
            cur.execute(
                "UPDATE LP_TESTATA SET STATO = 'PRONTO_PER_BOLLA' WHERE ID_LP = ?",
                lp_id,
            )
            conn.commit()
        except Exception:
            conn.rollback()
            raise
