from typing import Optional
from pydantic import BaseModel


class TabletInfo(BaseModel):
    id: str
    nome: str
    online: bool = False


class RegistraTabletRequest(BaseModel):
    id: str
    nome: str


class LPRigaOut(BaseModel):
    riga_id_arca: str
    articolo_codice: str
    articolo_descrizione: str
    quantita_originale: float
    quantita_corrente: float
    eliminata: bool


class LPHeaderOut(BaseModel):
    lp_id: str
    numero: Optional[str] = None
    data_creazione: Optional[str] = None
    cliente_destinazione: Optional[str] = None
    stato: str
    tablet_id: Optional[str] = None
    righe: list[LPRigaOut] = []


class AssegnaTabletRequest(BaseModel):
    tablet_id: str


class ModificaRigaRequest(BaseModel):
    quantita: float


class ConfermaLPResponse(BaseModel):
    lp_id: str
    esito: str
    dettaglio: Optional[str] = None
